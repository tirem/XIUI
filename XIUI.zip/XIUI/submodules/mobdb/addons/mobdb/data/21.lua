--Zone: Spire of Mea
--Zone ID: 21
return {
    Names = {
        ['Delver'] = { Name='Delver', Notorious=false, Aggro=true, Link=false, TrueSight=true, Job=0, MinLevel=37, MaxLevel=38, Immunities=5, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Envier'] = { Name='Envier', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=30, MaxLevel=30, Immunities=0, Respawn=0, Sight=true, Sound=false, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
        ['Seether'] = { Name='Seether', Notorious=false, Aggro=true, Link=true, TrueSight=true, Job=0, MinLevel=30, MaxLevel=30, Immunities=0, Respawn=0, Sight=false, Sound=false, Blood=false, Magic=false, JA=false, Scent=true, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1, Ice=1, Wind=1, Earth=1, Lightning=1, Water=1, Light=1, Dark=1} },
    },
    Indices = {
    },
};