--Zone: Reisenjima Henge
--Zone ID: 292
return {
    Names = {
    },
    Indices = {
    },
};